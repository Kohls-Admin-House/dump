					if string.sub(command, 1, 1) == ";" then
						command = ""
						game.Players:Chat("pm "..plr.Name.." your command Contains a ; at the start of it, This ain't HD admin kiddo")
					end
					if string.sub(command, 1, 1) == prefix then
						command = ""
						game.Players:Chat("pm "..plr.Name.." You can't use 'Shortcut V2 Commands class' xd!")
					end
					
					if string.sub(command, 1, 2) == "m " then
						game.Players:Chat("h \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n \n "..plr.Name..": I want to say something xd")
					elseif string.sub(command, 1, 2) == ":m" then
					elseif string.sub(command, 1, 12) == "gear me 947" then
						game.Players:Chat("h \n \n \n Shortcut v2: Lol this trash named "..plr.Name.." wanted to crash the server LOOOL epic fail \n \n \n ")
					elseif string.sub(command, 1, 13) == ":gear me 947" then
						game.Players:Chat("h \n \n \n Shortcut v2: Lol this trash named "..plr.Name.." wanted to crash the server LOOOL epic fail \n \n \n ")
						game.Players:Chat("pm "..plr.Name.." You can't use Message' lol! type !msg instead")
					elseif string.sub(command, 1, 1) == "-" then
						game.Players:Chat("h \n \n \n  "..plr.Name..": I can't ban people \n \n \n ")
						game.Players:Chat("pm "..plr.Name.." Also type unadmin to unperm yourself")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 1) == "." then
						game.Players:Chat("h \n \n \n  "..plr.Name..": I can't ban people \n \n \n ")
						game.Players:Chat("pm "..plr.Name.." Also type unadmin to unperm yourself")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 1) == "#" then
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
						game.Players:Chat("h \n \n \n  "..plr.Name..": My message got tagged meaning the command failed HELP ME PLEASE PLEASE BEG UWU \n \n \n ")
					elseif string.sub(command, 1, 1) == ">" then
						game.Players:Chat("h \n \n \n  "..plr.Name..": I can't ban people \n \n \n ")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 1) == "," then
						game.Players:Chat("h \n \n \n  "..plr.Name..": I can't ban people \n \n \n ")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 1) == "/" then
						game.Players:Chat("h \n \n \n  "..plr.Name..": I can't ban people \n \n \n ")
						game.Players:Chat("pm "..plr.Name.." Also type unadmin to unperm yourself")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 2) == ":h" then
						game.Players:Chat("h \n \n \n "..plr.Name..": \n \n \n ")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 3) == "nam" then
						game.Players:Chat("h \n \n \n "..plr.Name..": name me \n \n \n ")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 4) == ":nam" then
						game.Players:Chat("h \n \n \n "..plr.Name..": name me \n \n \n ")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 7) == "message" then
						game.Players:Chat("pm "..plr.Name.." You can t get a 'massage' lol!")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 8) == ":message" then
						game.Players:Chat("pm "..plr.Name.." You can t get a 'massage' lol!")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 2) == "pm" then
						game.Players:Chat("h lol "..plr.Name.." This guy tried to plot behind my back lol!")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 3) == ":pm" then
						game.Players:Chat("h lol "..plr.Name.." This guy tried to plot behind my back lol!")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 4) == "hint" then
						game.Players:Chat("pm "..plr.Name.." You cant use 'hint' sorry!")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 1) == "h" then
						game.Players:Chat("trip "..plr.Name.."")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 2) == "hi" then
						game.Players:Chat("h \n \n \n "..plr.Name..": Hello guys \n \n \n ")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 5) == ":pads" then
						game.Players:Chat("h \n \n \n "..plr.Name..": I use admin joy trash \n \n \n ")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
						game.Players:Chat("punish "..plr.Name.."")
					elseif string.sub(command, 1, 4) == "logs" then
						game.Players:Chat("freeze "..plr.Name.."!")
						game.Players:Chat("h \n \n \n Server Message: Funzy fact "..plr.Name.." has a crush on a guy named ''logs'' \n \n \n")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 5) == ":logs" then
						game.Players:Chat(":h \n \n \n Server Message: Funzy fact "..plr.Name.." has a crush on a guy named ''logs'' \n \n \n")

						game.Players:Chat("efirework "..plr.Name.."!")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 4) == "cmds" then
						game.Players:Chat("pm "..plr.Name.." Imagine having the Perm gamepass YET STILL NOT KNOWING THE COMMANDS IN 2022.")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 5) == ":cmds" then
						game.Players:Chat("pm "..plr.Name.." Imagine having the Perm gamepass YET STILL NOT KNOWING THE COMMANDS IN 2022.")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 9) == ":commands" then
						game.Players:Chat("pm "..plr.Name.." Imagine having the Perm gamepass YET STILL NOT KNOWING THE COMMANDS IN 2022.")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 5) == ":logs" then
						game.Players:Chat("efirework "..plr.Name.."!")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 4) == "size" then
						game.Players:Chat("size "..plr.Name.." 9.9")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 4) == "btoo" then
						game.Players:Chat("h \n \n \n "..plr.Name..": Working btools but client only \n \n \n ")
						game.Players:Chat("/btools "..plr.Name.."")
						game.Players:Chat("pm "..plr.Name.." The btools that you have is client sided so only you will see the effects. If you think others still see it then you deserve a punch in the face")
					elseif string.sub(command, 1, 5) == ":btoo" then
						game.Players:Chat("h \n \n \n "..plr.Name..": Working btools but client only \n \n \n ")
						game.Players:Chat("/btools "..plr.Name.."")
						game.Players:Chat("pm "..plr.Name.." The btools that you have is client sided so only you will see the effects. Play XlXi's game for Server Sided btools or some ####")
					elseif string.sub(command, 1, 5) == ":size" then
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
						game.Players:Chat("size "..plr.Name.." 10")
					elseif string.sub(command, 1, 6) == "freeze" then
						game.Players:Chat("speed "..plr.Name.." 0")
					elseif string.sub(command, 1, 7) == ":freeze" then
						game.Players:Chat("speed "..plr.Name.." 0")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
					elseif string.sub(command, 1, 7) == "unadmin" then
						game.Players:Chat("/unadmin "..plr.Name.."")
						game.Players:Chat("/reg Because this guy has Perm and Perm needs to be respected in 2022")
