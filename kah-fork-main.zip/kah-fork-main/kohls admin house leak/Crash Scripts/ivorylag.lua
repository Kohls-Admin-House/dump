-- Ivory Peri Server Pinger
-- Script by Humangas & thenoob

for i = 1,155,1 do wait(.1) -- change 50 to a higher value if you want to lag the server more
    game:GetService'Players':Chat(("gear me 000000000000000000108158379"))
end

for i,v in pairs(game.Players.LocalPlayer.Backpack:GetChildren()) do
    if v.Name == "IvoryPeriastron" then
        v.Parent = game.Players.LocalPlayer.Character
    else
        wait()
    end
    v.Remote:FireServer(Enum.KeyCode.Q)
end
wait()
game.Players.LocalPlayer.Character.Humanoid:UnequipTools()
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("behold the great ball of light","All")
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("join the disco server for more blessings","All")
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(".gg/rp4aKk5UBz","All")
wait(0.5)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
wait(2.50)
local HttpService, TPService = game:GetService("HttpService"), game:GetService("TeleportService")
local ServersToTP = HttpService:JSONDecode(game:HttpGet("https://games.roblox.com/v1/games/"..game.PlaceId.."/servers/Public?sortOrder=Asc&limit=100"))
for _, s in pairs(ServersToTP.data) do
   if s.playing ~= s.maxPlayers then
       TPService:TeleportToPlaceInstance(game.PlaceId, s.id)
   end
end
