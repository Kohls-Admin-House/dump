-- Fuck you niggers Kosmitek was here
-- https://www.youtube.com/watch?v=5Gj1jxKuMEQ


-- (nil)(nil, "\n")
repeat
until game.PlaceId ~= 112420803
Instance.new("ScreenGui").Name = "KOHGui"
Instance.new("ScreenGui").Parent = game.CoreGui
Instance.new("ScreenGui").ResetOnSpawn = false
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("ScreenGui"), "Frame"
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,691051126, 0, 0,423850566, 0)
Instance.new("ImageLabel").Size = UDim2.new(0, 273, 0, 217)
Instance.new("ImageLabel").Visible = false
Instance.new("ImageLabel").ZIndex = 0
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,08
Instance.new("Folder").Parent, Instance.new("Folder").Name = Instance.new("ImageLabel"), "Music"
Instance.new("ScrollingFrame").Parent, Instance.new("ScrollingFrame").Name = Instance.new("Folder"), "Gui"
Instance.new("ScrollingFrame").Active = true
Instance.new("ScrollingFrame").BackgroundColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("ScrollingFrame").BorderColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("ScrollingFrame").Position = UDim2.new(0,0149999997, 0, 0,130999997, 0)
Instance.new("ScrollingFrame").Size = UDim2.new(0, 269, 0, 179)
Instance.new("ScrollingFrame").Visible = false
Instance.new("ScrollingFrame").ScrollBarThickness = 3
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "AMOGUS"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,105042018, 0, 0,00431034481, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "AMOGUS"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "AMOGUS_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "ChugJug"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,386554629, 0, 0,00431034481, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Chug Jug"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "ChugJug_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "Buur"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,668067217, 0, 0,00431034481, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Buur"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Buur_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "SugarCrash"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,105042018, 0, 0,0900802463, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Sugar Crash"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "SugarCrash_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "Despacito2"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,386554629, 0, 0,0900802463, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Despacito 2"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Despacito2_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "MCMENTALATHISBEST"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,668067217, 0, 0,0900802463, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "MC Mental"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "MCMENTALATHISBEST_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "DreamMusic"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,105042018, 0, 0,179021657, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Dream Music"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "DreamMusic_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "TinyLittleAdiantumTrapRemix"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,386554629, 0, 0,179021657, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "TLATR"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "TinyLittleAdiantumTrapRemix_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "VibingMusic"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,668067217, 0, 0,179021657, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Vibing Music"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "VibingMusic_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "EPICSPANISHMUSIC"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,668067217, 0, 0,283224761, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Some Spanish Song (LOUD)"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "EPICSPANISHMUSIC_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "AnnoyingAAAA"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,386554629, 0, 0,283224761, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Annoying (LOUD)"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "AnnoyingAAAA_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "VibingMusic2"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,105042018, 0, 0,283224761, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Vibing Music 2"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "VibingMusic2_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "ChineseNewYear"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,668067217, 0, 0,382497698, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Chinese New Year"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "TextButton_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "TheHubIntro"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,105042018, 0, 0,382497698, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "The Hub Intro"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "TheHubIntro_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "Sayo-Nara"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,386554629, 0, 0,382497698, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Sayo-Nara"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Sayo-Nara_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("TextLabel").Parent, Instance.new("ImageLabel").SliceScale = Instance.new("Folder"), 0,06
Instance.new("TextLabel").BackgroundColor3 = Color3.fromRGB(29, 29, 29)
Instance.new("TextLabel").BackgroundTransparency = 1
Instance.new("TextLabel").BorderSizePixel = 0
Instance.new("TextLabel").Size = UDim2.new(0, 272, 0, 29)
Instance.new("TextLabel").Visible = false
Instance.new("TextLabel").ZIndex = 3
Instance.new("TextLabel").Font = Enum.Font.SourceSansSemibold
Instance.new("TextLabel").Text = "Kohls Admin Music Gui"
Instance.new("TextLabel").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextLabel").TextSize = 24
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("TextLabel"), "Close"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(132, 0, 2)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,928571343, 0, 0, 0)
Instance.new("TextButton").Size = UDim2.new(0, 17, 0, 17)
Instance.new("TextButton").ZIndex = 3
Instance.new("TextButton").Font = Enum.Font.Cartoon
Instance.new("TextButton").Text = "X"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(126, 2, 19)
Instance.new("TextButton").TextSize = 20
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Close_Roundify_5px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(132, 0, 2)
Instance.new("ImageLabel").ImageTransparency = 1
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,05
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextLabel"), "TextLabel_Roundify_8px"
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").ZIndex = 2
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(29, 29, 29)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,08
Instance.new("TextLabel").Parent, Instance.new("Folder").Parent, Instance.new("Folder").Name = Instance.new("Folder"), Instance.new("ImageLabel"), "Gear"
Instance.new("TextLabel").BackgroundColor3 = Color3.fromRGB(29, 29, 29)
Instance.new("TextLabel").BackgroundTransparency = 1
Instance.new("TextLabel").BorderSizePixel = 0
Instance.new("TextLabel").Size = UDim2.new(0, 272, 0, 29)
Instance.new("TextLabel").ZIndex = 2
Instance.new("TextLabel").Font = Enum.Font.SourceSansSemibold
Instance.new("TextLabel").Text = "Kohls Admin Gear Gui"
Instance.new("TextLabel").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextLabel").TextSize = 24
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("TextLabel"), "Close"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(132, 0, 2)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,928571343, 0, 0, 0)
Instance.new("TextButton").Size = UDim2.new(0, 17, 0, 17)
Instance.new("TextButton").ZIndex = 3
Instance.new("TextButton").Font = Enum.Font.Cartoon
Instance.new("TextButton").Text = "X"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(126, 2, 19)
Instance.new("TextButton").TextSize = 20
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Close_Roundify_8px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(132, 0, 2)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,08
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextLabel"), "TextLabel_Roundify_8px"
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(29, 29, 29)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,08
Instance.new("ScrollingFrame").Parent, Instance.new("ScrollingFrame").Name = Instance.new("Folder"), "Gui"
Instance.new("ScrollingFrame").Active = true
Instance.new("ScrollingFrame").BackgroundColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("ScrollingFrame").BorderColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("ScrollingFrame").BorderSizePixel = 0
Instance.new("ScrollingFrame").Position = UDim2.new(0,0146520147, 0, 0,131129116, 0)
Instance.new("ScrollingFrame").Size = UDim2.new(0, 269, 0, 179)
Instance.new("ScrollingFrame").ScrollBarThickness = 3
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "EpicSword"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,105042018, 0, 0,00431034481, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Epic Sword"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "EpicSword_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "Slide"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,386554629, 0, 0,00431034481, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Slide"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Slide_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "Water"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,668067217, 0, 0,00431034481, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Water"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Water_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "GearJail"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,109058082, 0, 0,0992331877, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Gear Un/Lock"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "GearJail_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "Drone"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,672083259, 0, 0,0992331877, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Drone"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Drone_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "Time Stop"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,109058082, 0, 0,189956814, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Time Stop"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Time Stop_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "RailGun"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,3905707, 0, 0,189956814, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Rail Gun"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "RailGun_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "Machete"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,672083259, 0, 0,189956814, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Machete"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Machete_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "SubspaceTripmine"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,672083259, 0, 0,37948066, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Invis Tripmine"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "SubspaceTripmine_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "RageTable"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,3905707, 0, 0,37948066, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Rage Table"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "RageTable_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "BoomBox"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,109058082, 0, 0,287642092, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Boom Box"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "BoomBox_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "Paint"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,3905707, 0, 0,0992331877, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Paint Bucket"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Paint_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "InvisPads"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,672083259, 0, 0,287642092, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Invis Pads"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "InvisPads_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "Detain"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,3905707, 0, 0,287642092, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Detain"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Detain_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScrollingFrame"), "BlackHole"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,109058082, 0, 0,37948066, 0)
Instance.new("TextButton").Size = UDim2.new(0, 53, 0, 22)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Black Hole Sword"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "BlackHole_Roundify_6px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(24, 24, 24)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,06
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("Folder"), "GearOpen"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,302855968, 0, 0,675707996, 70)
Instance.new("TextButton").Size = UDim2.new(0, 27, 0, 25)
Instance.new("TextButton").Visible = false
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "<"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "GearOpen_Roundify_5px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,05
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("Folder"), "MusicOpen"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,593117118, 0, 0,675649762, 70)
Instance.new("TextButton").Size = UDim2.new(0, 27, 0, 25)
Instance.new("TextButton").ZIndex = 2
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = ">"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextScaled = true
Instance.new("TextButton").TextSize = 14
Instance.new("TextButton").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "MusicOpen_Roundify_5px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,05
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("ImageLabel"), "VisualizerFogColor"
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(1,04802203, 0, 0,78811121, 0)
Instance.new("ImageLabel").Size = UDim2.new(0, 106, 0, 45)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(42, 42, 42)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("TextBox").Parent, Instance.new("ImageLabel").SliceScale = Instance.new("ImageLabel"), 0,07
Instance.new("TextBox").BackgroundColor3 = Color3.fromRGB(42, 42, 42)
Instance.new("TextBox").BackgroundTransparency = 1
Instance.new("TextBox").BorderColor3 = Color3.fromRGB(42, 42, 42)
Instance.new("TextBox").BorderSizePixel = 0
Instance.new("TextBox").Position = UDim2.new(0, 0, 0,377777696, 0)
Instance.new("TextBox").Size = UDim2.new(0, 106, 0, 28)
Instance.new("TextBox").ZIndex = 2
Instance.new("TextBox").Font = Enum.Font.SourceSans
Instance.new("TextBox").Text = "Click here to change fogcolor"
Instance.new("TextBox").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextBox").TextScaled = true
Instance.new("TextBox").TextSize = 14
Instance.new("TextBox").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextBox"), "TextBox_Roundify_7px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,464285731, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(42, 42, 42)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("TextLabel").Parent, Instance.new("ImageLabel").SliceScale = Instance.new("ImageLabel"), 0,07
Instance.new("TextLabel").BackgroundColor3 = Color3.fromRGB(42, 42, 42)
Instance.new("TextLabel").BackgroundTransparency = 1
Instance.new("TextLabel").BorderColor3 = Color3.fromRGB(42, 42, 42)
Instance.new("TextLabel").BorderSizePixel = 0
Instance.new("TextLabel").Size = UDim2.new(0, 106, 0, 16)
Instance.new("TextLabel").ZIndex = 2
Instance.new("TextLabel").Font = Enum.Font.SourceSans
Instance.new("TextLabel").Text = "Visualizer Fog Color"
Instance.new("TextLabel").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextLabel").TextScaled = true
Instance.new("TextLabel").TextSize = 14
Instance.new("TextLabel").TextWrapped = true
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextLabel"), "TextLabel_Roundify_7px"
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(42, 42, 42)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,07
Instance.new("TextButton").Parent, Instance.new("TextButton").Name = Instance.new("ScreenGui"), "Open"
Instance.new("TextButton").BackgroundColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("TextButton").BackgroundTransparency = 1
Instance.new("TextButton").BorderSizePixel = 0
Instance.new("TextButton").Position = UDim2.new(0,977272689, 0, 0,710650802, 0)
Instance.new("TextButton").Size = UDim2.new(0, 32, 0, 17)
Instance.new("TextButton").ZIndex = 549384
Instance.new("TextButton").Font = Enum.Font.SourceSans
Instance.new("TextButton").Text = "Open"
Instance.new("TextButton").TextColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("TextButton").TextSize = 14
Instance.new("ImageLabel").Parent, Instance.new("ImageLabel").Name = Instance.new("TextButton"), "Open_Roundify_5px"
Instance.new("ImageLabel").Active = true
Instance.new("ImageLabel").AnchorPoint = Vector2.new(0,5, 0,5)
Instance.new("ImageLabel").BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Instance.new("ImageLabel").BackgroundTransparency = 1
Instance.new("ImageLabel").Position = UDim2.new(0,5, 0, 0,5, 0)
Instance.new("ImageLabel").Selectable = true
Instance.new("ImageLabel").Size = UDim2.new(1, 0, 1, 0)
Instance.new("ImageLabel").Image = "rbxassetid://3570695787"
Instance.new("ImageLabel").ImageColor3 = Color3.fromRGB(39, 39, 39)
Instance.new("ImageLabel").ScaleType = Enum.ScaleType.Slice
Instance.new("ImageLabel").SliceCenter = Rect.new(100, 100, 100, 100)
Instance.new("ImageLabel").SliceScale = 0,05
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000006132224076")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000006429721293")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000006087189175")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000005914756563")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000002993762545")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000002649590402")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000006029210056")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000003650040936")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000004461953104")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000004748003994")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000006671006085")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000002023642240")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000001439619167")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000005532624633")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("music 0000000000000000000000000000000000000000000000000000000001248405065")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    va.Parent.Parent.Parent.Parent.Parent.Open.Visible = true
    va.Parent.Parent.Parent.Parent.Visible = false
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    va.Parent.Parent.Parent.Parent.Parent.Open.Visible = true
    va.Parent.Parent.Parent.Parent.Visible = false
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000068539623")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000019704064")
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000032356064")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 000000000000000000000000000000000000000000000000000000000236438668")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000082357101")
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000059190534")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 000000000000000000000000000000000000000000000000000000000987032734")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000071037101")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000079446473")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 000000000000000000000000000000000000000000000000000000000123234673")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000011999247")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 000000000000000000000000000000000000000000000000000000000243788010")
  end)
end)()
coroutine.wrap(function()
  print("Hello world!")
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 000000000000000000000000000000000000000000000000000000000212641536")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000018474459")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000029099749")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000081330766")
    game:GetService("Players"):Chat("gear me 00000000000000000000000000000000000000000000000000000000074385399")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    game:GetService("Players"):Chat("gear me 000000000000000000000000000000000000000000000000000000000268586231")
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    va.Parent.Parent.TextLabel.Visible = true
    va.Parent.Parent.Gui.Visible = true
    va.Parent.Visible = false
    va.Parent.Parent.Parent.Music.TextLabel.Visible = false
    va.Parent.Parent.Parent.Music.Gui.Visible = false
    va.Parent.Parent.MusicOpen.Visible = true
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    va.Parent.Parent.Parent.Music.TextLabel.Visible = true
    va.Parent.Parent.Parent.Music.Gui.Visible = true
    va.Parent.Visible = false
    va.Parent.Parent.TextLabel.Visible = false
    va.Parent.Parent.Gui.Visible = false
    va.Parent.Parent.GearOpen.Visible = true
  end)
end)()
coroutine.wrap(function()
  Instance.new("LocalScript", va).Parent.MouseButton1Down:connect(function()
    va.Parent.Parent.Frame.Visible = true
    va.Parent.Visible = false
  end)
end)()
coroutine.wrap(function()
  frame = Instance.new("LocalScript", va).Parent.Frame
  frame.Draggable = true
  frame.Active = true
  frame.Selectable = true
end)()
game.StarterGui:SetCore("SendNotification", {
  Title = "Script Executed!",
  Text = "KohlSploit is currently loading!",
  Duration = 5
})
Whitelisted = {}
Blacklisted = {"ijemy7"}
function rjn()
  game:GetService("TeleportService"):Teleport(game.PlaceId, va.LocalPlayer)
end
function createbackupregen()
  Instance.new("Part").BrickColor = BrickColor.new("Electric blue")
  Instance.new("Part").Name = "backupregen"
  Instance.new("Part").Parent = va
  Instance.new("Part").Position = Vector3.new(28, 4, -1)
  Instance.new("Part").Anchored = true
  va.Regen.ClickDetector.Parent = va.backupregen
end
function transformToColor3(a)
  a = a
  return Color3.new(a.r, a.g, a.b)
end
warn("KohlSploit made by Humangas.")
warn("Version V1.9.5")
warn("Contact my Discord if you have any problems. Humangas#7921")
warn("Chatlogs was made by CoolUI/opencup")
warn("Rainbowcs command was made by TheNoob")
print("Update logs")
print("Fixed the Funni Command And Added Anti Spin, and you can now say any command however you'd like to. For example in lowercase or uppercase. June, 2, 2021")
print("Added fpsdrop command. June, 3, 2021")
print("Added whitelist command. Also added mymusiconly (mymusicon) command, and rescripted the spam command. June, 4, 2021")
print("Changed how the boommusic command works. June, 5, 2021")
print("Added anomaly, Pastel, and Sunset command. June, 6, 2021")
print("Added callrandom command, and a serverhop command. June, 7, 2021")
print("Added AntiFling, AntiName, AntiFire, and Mutebboxes. June, 8, 2021")
game:GetService("Players").LocalPlayer.Chatted:Connect(function(a)
  a = a
  if string.sub(a:lower(), 0, 50) == prefix .. "scmds" then
    warn("List of commands in this script.")
    wait(0,7)
    print(prefix .. "whitelist (plrs name, and needs admin for it to work for whitelisted people)")
    print(prefix .. "robbyk -- Anti Obby Kill")
    print(prefix .. "AntiKill")
    print(prefix .. "AntiSpin")
    print(prefix .. "AntiMSG -- Basically removes the h, h/, m, and m/ from appearing on your screen")
    print(prefix .. "AntiPunish")
    print(prefix .. "AntiJail")
    print(prefix .. "AntiSeizure")
    print(prefix .. "AntiFling")
    print(prefix .. "AntiName")
    print(prefix .. "AntiFire")
    print(prefix .. "AntiDog")
    print(prefix .. "AntiGS -- An anti gray scale for that one time stop gear")
    print(prefix .. "AntiBlind")
    print(prefix .. "AntiMusic")
    print(prefix .. "AntiDMG -- Heal once you're below your max hp")
    print(prefix .. "AntiFreeze")
    print(prefix .. "AntiSlag -- Removes the Ultimate Drive Speedster from everyones inventories, which causes the server to lag if there is too many")
    print(prefix .. "AntiCrash -- No one can crash with Vampire Vanquisher")
    print(prefix .. "AllAntis -- Execute all the Anti Commands at once")
    warn(prefix .. "These Antis are toggleable just add an No to the front of an Anti command for example :NoAntiKill")
    print(prefix .. "house -- Tp to house")
    print(prefix .. "lfrp -- Look for regen/reset pad")
    print(prefix .. "lfbp -- Look for baseplate")
    print(prefix .. "pads -- Tp to Admin Pads")
    print(prefix .. "funni -- Mess up peoples controls")
    print(prefix .. "dg -- Destroy Graphics? idk do the command and you'll see what I mean")
    print(prefix .. "chatlogs")
    print(prefix .. "fpsdrop (plr name) -- drop someones fps lol (say " .. prefix .. "stop, to stop the command)")
    print(prefix .. "rj or " .. prefix .. "rejoin -- Rejoin the game")
    print(prefix .. "shop or " .. prefix .. "serverhop -- Join another server")
    print(prefix .. "anomaly (plr) -- ascend someone")
    print(prefix .. "bangears (plr name) -- Ban someones gears")
    print(prefix .. "boo -- Kind of a creepy way to shutdown")
    print(prefix .. "shutdown -- Shuts the server down.")
    print(prefix .. "cbackupr -- Create a backup regen next to obby (only works for you, and if the regen pad is still in the game and not deleted lol.)")
    print(prefix .. "bregen -- Use this command instead of :regen if you use :cbackupr")
    print(prefix .. "regen -- Reset Admin Pads anywhere")
    print(prefix .. "cmalled -- GET COCONUT MALLED ??????")
    print(prefix .. "mutebboxes -- Mutes all boomboxes (to stop type :unmutebboxes")
    print(prefix .. "mymusicon (id) -- say " .. prefix .. "mymusicno to stop")
    print(prefix .. "slag -- Lag the server (recommended to say :stop after like 5 seconds or so)")
    print(prefix .. "spam (command here) -- stop with " .. prefix .. "stop")
    print(prefix .. "vis -- MUSIC VISUALIZER (only works when music is playing)")
    print(prefix .. "stopvis -- To stop the VISUALIZER")
    print(prefix .. "viscolor -- To have your own color to the VISUALIZER")
    print(prefix .. "noviscolor -- To have no color to the VISUALIZER")
    warn("If you want to change the VISUALIZER color open the gui and on the bottom right of your screen there is a textbox that takes RGB data to change color.")
    print(prefix .. "boommusic (id) -- To play music with boomboxes instead")
    print(prefix .. "pastel -- pastel shading")
    print(prefix .. "sunrise -- Epic sunrise visuals.")
    print(prefix .. "sunset -- Epic sunset visuals.")
    print(prefix .. "perm -- Basically perm? I mean it'll instantly give you a pad if it gets reset or smthn")
    print(prefix .. "bcrash -- To crash the server BLUESCREEN STYLE")
    print(prefix .. "crash -- To crash the server.")
    print(prefix .. "callrandom -- Color everything random")
    print(prefix .. "callog -- Color everything to the original color")
    if va.LocalPlayer.Name == "Humangas" then
      wait()
      warn("ONLY SPECIFIC PEOPLE CAN SEE THESE COMMANDS BELOW, AND YOU'RE ONE OF THEM")
      print(prefix .. "SOS -- Activate SOS (saves server from specific players)")
      print(prefix .. "KOS -- Activate KOS (crashes server if specific player joins)")
      print(prefix .. "calldark -- Colors everything with a purple/black theme")
      print(prefix .. "calldarkwfx -- Same thing as command above but with effects.")
      warn("SOS and KOS can be toggled by adding a (Toggle) in front like this ToggleKOS")
    else
      wait()
    end
    game.StarterGui:SetCore("SendNotification", {
      Title = "Notice!",
      Text = "Check console (F9) for a list of commands!",
      Duration = 5
    })
    wait(5)
    warn("Thanks for using my script!")
  end
  if string.sub(a:lower(), 0, 5) == prefix .. "spam" then
    vb = true
    while vb == true do
      va:Chat(string.sub(a, 7))
      wait()
    end
  elseif string.sub(a:lower(), 0, 50) == prefix .. "stop" then
    vb = false
  end
  if string.sub(a:lower(), 0, 50) == prefix .. "slag" then
    va:Chat(":spam gear all 000000000000000000000000000000000000000000000000000000000253519495")
  end
  if string.sub(a:lower(), 0, 50) == prefix .. "chatlogs" then
    loadstring(game:HttpGet("https://raw.githubusercontent.com/MaybeHumanBut/Pog/main/coolepiccl"))()
  end
  if string.sub(a:lower(), 0, 50) == prefix .. "robbyk" then
    vc.Terrain._Game.Workspace.Obby.Jump.TouchInterest:Destroy()
    for fg = 1, 9 do
      vc.Terrain._Game.Workspace.Obby["Jump" .. fg].TouchInterest:Destroy()
    end
  end
  if string.sub(a:lower(), 0, 10) == ":mymusicon" then
    if vd == true then
      vd = false
      wait(0,2)
      vd = true
    else
      vd = true
    end
    musicid = string.sub(a, 12)
    while true do
      if vd == true then
        if not vc.Terrain._Game.Folder:FindFirstChild("Sound", true) then
          va:Chat("music 00000000000000" .. musicid)
          wait(0,2)
        elseif vc.Terrain._Game.Folder:FindFirstChild("Sound", true).SoundId ~= "http://www.roblox.com/asset/?id=" .. musicid then
          va:Chat("music 00000000000000" .. musicid)
          wait(0,2)
        elseif vc.Terrain._Game.Folder:FindFirstChild("Sound", true).Playing == false then
          va.Terrain._Game.Folder:FindFirstChild("Sound", true).Playing = true
          wait(0,2)
        end
        wait()
        elseif string.sub(a:lower(), 0, 10) == ":mymusicno" then
          vd = false
          wait(0,1)
          va:Chat("stopmusic")
        end
      end
    end
  if string.sub(a:lower(), 0, 9) == prefix .. "bangears" then
    va:Chat("gear me 000000000000000000000000000000000000000000000000000082357101")
    wait(0,5)
    va.LocalPlayer.Character.Humanoid:EquipTool(va.LocalPlayer.Backpack.PortableJustice)
    wait(0,5)
    names = va:GetChildren()
    for fh, fj in pairs(names) do
      strlower = string.lower(fj.Name)
      sub = string.sub(strlower, 1, #string.sub(a:lower(), 11))
      if string.sub(a:lower(), 11) == sub then
        va:Chat("unff " .. fj.Name)
        wait()
        va:Chat("ungod " .. fj.Name)
        wait()
        va:Chat("gear me 000000000000000000000000000000000000000000000000000082357101")
        va.LocalPlayer.Character.HumanoidRootPart.CFrame = fj.Character.HumanoidRootPart.CFrame
        wait(0,25)
        workspace[va.LocalPlayer.Name].PortableJustice.MouseClick:FireServer(workspace[fj.Name])
        wait(0,5)
        va:Chat("reset " .. fj.Name)
      end
    end
  end
  if string.sub(a:lower(), 0, 10) == prefix .. "whitelist" then
    names = va:GetChildren()
    for fh, fj in pairs(names) do
      strlower = string.lower(fj.Name)
      sub = string.sub(strlower, 1, #string.sub(a:lower(), 12))
      plrname = fj.Name
      if string.sub(a:lower(), 12) == sub then
        user = fj.Name
        table.insert(Whitelisted, fj.Name)
        va:Chat("pm " .. plrname .. " You have been Whitelisted!, Say " .. prefix .. "scmds for a list of commands!")
        if table.find(Whitelisted, fj.Name) then
          fj.Chatted:Connect(function(a)
            a = a
            if string.sub(a, 1, 5) == prefix .. "spam" then
              va = true
              spam(string.sub(a, 7))
            elseif a == ":stop" then
              va = false
            end
            function spam(a)
              a = a
              while va == true do
                wait()
                vb:Chat(a)
              end
            end
            if string.sub(a:lower(), 0, 20) == prefix .. "scmds" then
              vb:Chat("pm " .. user .. " look at logs")
              wait()
              vb:Chat("ff " .. prefix .. "spam (command)")
              wait()
              vb:Chat("ff " .. prefix .. "fpsdrop (plr) (" .. prefix .. "stop to stop)")
              wait()
              vb:Chat("ff " .. prefix .. "AntiKill")
              wait()
              vb:Chat("ff " .. prefix .. "AntiPunish")
              wait()
              vb:Chat("ff " .. prefix .. "AntiSpin")
              wait()
              vb:Chat("ff " .. prefix .. "AntiJail")
              wait()
              vb:Chat("ff " .. prefix .. "AntiDMG")
              wait()
              vb:Chat("ff " .. prefix .. "AntiDog")
              wait()
              vb:Chat("ff " .. prefix .. "AntiSeizure")
              wait()
              vb:Chat("ff " .. prefix .. "AntiFreeze")
            end
            if string.sub(a:lower(), 0, 20) == prefix .. "antifreeze" then
              vc = true
              while vc == true do
                while vb.v.Character:FindFirstChild("ice", true) do
                  vb:Chat("thaw " .. user)
                  wait(0,2)
                end
                wait()
              end
            elseif string.sub(a:lower(), 0, 20) == prefix .. "noantifreeze" then
              vc = false
            end
            if string.sub(a:lower(), 0, 20) == prefix .. "antispin" then
              vd = true
              while vd == true do
                while ve.Character.Torso:FindFirstChild("SPINNER") do
                  vb:Chat("unspin " .. user)
                  wait(0,2)
                end
                wait()
              end
            elseif string.sub(a:lower(), 0, 20) == prefix .. "noantispin" then
              vd = false
            end
            if string.sub(a:lower(), 0, 20) == prefix .. "antidog" then
              vg = true
              while vg == true do
                while ve.Character:FindFirstChild("Addon") do
                  vb:Chat("undog " .. user)
                  wait(0,2)
                end
                wait()
              end
            elseif string.sub(a:lower(), 0, 20) == prefix .. "noantidog" then
              vg = false
            end
            if string.sub(a:lower(), 0, 20) == prefix .. "antiseizure" then
              vh = true
              while vh == true do
                while ve.Character:FindFirstChild("Seizure") do
                  vb:Chat("unseizure " .. user)
                  wait(0,2)
                end
                wait()
              end
            elseif string.sub(a:lower(), 0, 20) == prefix .. "noantiseizure" then
              vh = false
            end
            if string.sub(a:lower(), 0, 20) == prefix .. "antikill" then
              vj = true
              while vj == true do
                while ve.Character.Humanoid.Health == 0 do
                  vb:Chat("reset " .. user)
                  wait(0,2)
                end
                wait()
              end
            elseif string.sub(a:lower(), 0, 20) == prefix .. "noantikill" then
              vj = false
            end
            if string.sub(a:lower(), 0, 20) == prefix .. "antipunish" then
              vk = true
              while vk == true do
                while game.Lighting:FindFirstChild(user) do
                  vb:Chat("unpunish " .. user)
                  wait(0,2)
                end
                wait()
              end
            elseif string.sub(a:lower(), 0, 20) == prefix .. "noantipunish" then
              vk = false
            end
            if string.sub(a:lower(), 0, 20) == prefix .. "antijail" then
              vl = true
              while vl == true do
                while vm.Terrain._Game.Folder:FindFirstChild(user .. "'s jail") do
                  vb:Chat("unjail " .. user)
                  wait(0,2)
                end
                wait()
              end
            elseif string.sub(a:lower(), 0, 20) == prefix .. "noantijail" then
              vl = false
            end
            if string.sub(a:lower(), 0, 20) == prefix .. "antidmg" then
              vo = true
              while vo == true do
                while ve.Character.Humanoid.MaxHealth > ve.Character.Humanoid.Health do
                  vb:Chat("health " .. user(" ") .. ve.Character.Humanoid.MaxHealth)
                  wait(0,2)
                end
                wait()
              end
            elseif string.sub(a:lower(), 0, 20) == prefix .. "noantidmg" then
              vo = false
            end
            if string.sub(a:lower(), 0, 8) == prefix .. "fpsdrop" then
              names = vb:GetChildren()
              for fh, fj in pairs(names) do
                strlower = string.lower(fj.Name)
                sub = string.sub(strlower, 1, #string.sub(a:lower(), 10))
                if string.sub(a:lower(), 10) == sub then
                  vb:Chat("jail " .. fj.Name)
                  wait(0,1)
                  vb:Chat("punish " .. fj.Name)
                  wait(0,1)
                  vb:Chat(prefix .. "spam explode " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " " .. fj.Name .. " ")
                end
              end
            end
          end)
        else
          wait()
        end
      end
    end
  end
  if string.sub(a:lower(), 0, 8) == prefix .. "anomaly" then
    va:Chat("setgrav " .. string.sub(a, 10) .. " -252.2")
    wait()
    va:Chat("stun " .. string.sub(a, 10))
    wait()
    va:Chat("fix")
    wait()
    va:Chat("time -")
    wait()
    va:Chat("glow " .. string.sub(a, 10) .. " 434287309 434287309 434287309")
    wait(0,1)
    va:Chat("music 00000000000000000000000000000000000000000000909227073")
  end
  if string.sub(a, 0, 6) == prefix .. "pmbug" and va.LocalPlayer.Name == "Humangas" then
    va:Chat(":spam pm " .. string.sub(a, 8) .. " ############################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################################")
  end
  if string.sub(a:lower(), 0, 5) == prefix .. "hank" and va.LocalPlayer.Name == "Humangas" then
    va:Chat("removehats " .. string.sub(a, 7))
    wait()
    va:Chat("unpackage " .. string.sub(a, 7))
    wait()
    va:Chat("paint " .. string.sub(a, 7) .. " mid gray")
    wait()
    va:Chat("pants " .. string.sub(a, 7) .. " 6583353014")
    wait()
    va:Chat("shirt " .. string.sub(a, 7) .. " 6583388856")
    wait()
    va:Chat("hat " .. string.sub(a, 7) .. " 753986964")
    wait()
    va:Chat("hat " .. string.sub(a, 7) .. " 4753644287")
    wait()
    va:Chat("hat " .. string.sub(a, 7) .. " 4099921662")
    wait()
    va:Chat("hat " .. string.sub(a, 7) .. " 4087527067")
  end
  if string.sub(a:lower(), 0, 6) == prefix .. "fnfbf" and va.LocalPlayer.Name == "Humangas" then
    va:Chat("removehats " .. string.sub(a, 8))
    wait()
    va:Chat("unpackage " .. string.sub(a, 8))
    wait()
    va:Chat("paint " .. string.sub(a, 8) .. " light orange")
    wait()
    va:Chat("pants " .. string.sub(a, 8) .. " 6672406943")
    wait()
    va:Chat("shirt " .. string.sub(a, 8) .. " 6672405141")
    wait()
    va:Chat("hat " .. string.sub(a, 8) .. " 6135459764")
    wait()
    va:Chat("hat " .. string.sub(a, 8) .. " 3185830268")
  end
  if string.sub(a:lower(), 0, 9) == prefix .. "extricky" and va.LocalPlayer.Name == "Humangas" then
    va:Chat("removehats " .. string.sub(a, 11))
    wait()
    va:Chat("unpackage " .. string.sub(a, 11))
    wait()
    va:Chat("paint " .. string.sub(a, 11) .. " really black")
    wait()
    va:Chat("pants " .. string.sub(a, 11) .. " 3063900117")
    wait()
    va:Chat("shirt " .. string.sub(a, 11) .. " 3830132554")
    wait()
    va:Chat("hat " .. string.sub(a, 11) .. " 5895519172")
    wait()
    va:Chat("hat " .. string.sub(a, 11) .. " 15469944")
    wait()
    va:Chat("hat " .. string.sub(a, 11) .. " 5735725450")
    wait()
    va:Chat("hat " .. string.sub(a, 11) .. " 4684072652")
  end
  if string.sub(a:lower(), 0, 20) == prefix .. "loglogs" and va.LocalPlayert.Name == "Humangas" then
    if not va.LocalPlayer.PlayerGui:FindFirstChild("ScrollGui", true) then
      va:Chat("logs")
      wait(0,2)
      for fg, fh in pairs(va.LocalPlayer.PlayerGui.ScrollGui.TextButton.Frame.Frame:GetChildren()) do
        print(fh.Text)
      end
    else
      for fg, fh in pairs(va.LocalPlayer.PlayerGui.ScrollGui.TextButton.Frame.Frame:GetChildren()) do
        print(fh.Text)
      end
    end
  end
  if string.sub(a:lower(), 0, 50) == prefix .. "rainbowcs" then
    ve = true
    while ve == true do
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 0 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 240 0 15")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 225 0 30")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 210 0 45")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 195 0 60")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 180 0 75")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 165 0 90")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 150 0 105")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 135 0 120")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 120 0 135")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 105 0 150")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 90 0 165")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 75 0 180")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 60 0 195")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 45 0 210")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 30 0 225")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 15 0 240")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 0 0 255")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 15 15 240")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 30 30 225")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 45 45 210")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 60 60 195")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 75 75 180")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 90 90 165")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 105 105 150")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 120 120 135")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 135 135 120")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 150 150 105")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 165 165 90")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 180 180 75")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 195 195 60")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 210 210 45")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 225 225 30")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 240 240 15")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 255 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 240 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 225 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 210 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 195 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 180 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 165 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 150 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 135 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 120 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 105 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 90 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 75 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 60 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 45 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 30 0")
      wait(0,01);
      (function(...)
        va:Chat(...)
      end)("colorshifttop 255 15 0")
      wait(0,01)
    end
  elseif string.sub(a:lower(), 0, 50) == prefix .. "norainbowcs" then
    ve = false
    wait(0,2)
    va.Chat("fix")
  end
  if string.sub(a:lower(), 0, 50) == prefix .. "czydisco" and va.LocalPlayer.Name == "Humangas" then
    vg = true
    while vg == true do
      va:Chat("fogcolor " .. math.random(500, 5000) .. " " .. math.random(500, 5000) .. " " .. math.random(500, 5000))
      wait(0,07)
    end
  elseif string.sub(a:lower(), 0, 50) == prefix .. "noczydisco" then
    vg = false
    wait(0,3)
    va:Chat("fix")
  end
  if string.sub(a:lower(), 0, 8) == prefix .. "fpsdrop" then
    va:Chat("jail " .. string.sub(a:lower(), 10))
    wait(0,1)
    va:Chat("punish " .. string.sub(a:lower(), 10))
    wait(0,1)
    va:Chat(prefix .. "spam explode " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:lower(), 10) .. " " .. string.sub(a:
