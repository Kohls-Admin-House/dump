for i,v in pairs(game.Workspace.Terrain["_Game"].Workspace.Obby:GetChildren()) do
    if v.Name == "Jump" then
        v:Destroy()
    end
end
for i,v in pairs(game.Workspace.Terrain["_Game"].Workspace.Obby:GetChildren()) do
    if v.Name == "Jump1" then
        v:Destroy()
    end
end
for i,v in pairs(game.Workspace.Terrain["_Game"].Workspace.Obby:GetChildren()) do
    if v.Name == "Jump2" then
        v:Destroy()
    end
end
for i,v in pairs(game.Workspace.Terrain["_Game"].Workspace.Obby:GetChildren()) do
    if v.Name == "Jump3" then
        v:Destroy()
    end
end
for i,v in pairs(game.Workspace.Terrain["_Game"].Workspace.Obby:GetChildren()) do
    if v.Name == "Jump4" then
        v:Destroy()
    end
end
for i,v in pairs(game.Workspace.Terrain["_Game"].Workspace.Obby:GetChildren()) do
    if v.Name == "Jump5" then
        v:Destroy()
    end
end
for i,v in pairs(game.Workspace.Terrain["_Game"].Workspace.Obby:GetChildren()) do
    if v.Name == "Jump6" then
        v:Destroy()
    end
end
for i,v in pairs(game.Workspace.Terrain["_Game"].Workspace.Obby:GetChildren()) do
    if v.Name == "Jump7" then
        v:Destroy()
    end
end
for i,v in pairs(game.Workspace.Terrain["_Game"].Workspace.Obby:GetChildren()) do
    if v.Name == "Jump8" then
        v:Destroy()
    end
end
for i,v in pairs(game.Workspace.Terrain["_Game"].Workspace.Obby:GetChildren()) do
    if v.Name == "Jump9" then
        v:Destroy()
    end
end

game:GetService'Players':Chat(("h From now on, this server is protected thanks to "..game.Players.LocalPlayer.Name.."'s script! (credits to banbydoo for making this script)"))
for i,vai in pairs(game.Players:GetChildren()) do
    while vai ~= nil do wait(0.3)
if #game.Players:GetChildren() < #game.Players:GetChildren() and #game.Players:GetChildren() > #game.Players:GetChildren() then
    wait(0.6)
end
        for i,v in pairs(game.Players:GetChildren()) do
            if game:GetService("Workspace"):FindFirstChild(tostring(v.Name)) == nil then
            game:GetService("Players"):Chat("unpunish all")
            wait(0.2)
            end
            if v.Character.Humanoid ~= nil then
            if v.Character.Humanoid.Health < 100 then
                if v.Character.Humanoid.Health ~= 0 then
                game:GetService'Players':Chat(("health "..v.Name.." 100"))
                if v.Character.Humanoid.Health < 51 then
                    game:GetService'Players':Chat(("ff "..v.Name))
                end
                end
            elseif #game.Players:GetChildren() < #game.Players:GetChildren() and #game.Players:GetChildren() > #game.Players:GetChildren() then
            end
            if v.Character.Humanoid.Health == 0 then
                game:GetService'Players':Chat(("reset "..v.Name))
            elseif #game.Players:GetChildren() < #game.Players:GetChildren() and #game.Players:GetChildren() > #game.Players:GetChildren() then
                end
            if v.Character.Humanoid.PlatformStand == true then
                game:GetService'Players':Chat(("unstun "..v.Name))
            elseif #game.Players:GetChildren() < #game.Players:GetChildren() and #game.Players:GetChildren() > #game.Players:GetChildren() then
            end
            end
            for i,bruv in pairs(v.Character:GetChildren()) do
                if bruv.Name == "Seizure" then
                    game:GetService'Players':Chat(("unseizure "..v.Name))
                end
                end
            for i,ve in pairs(v.Backpack:GetChildren()) do
                if ve.Name == "VampireVanquisher" then
                    game:GetService'Players':Chat(("reset "..v.Name))
                    game:GetService'Players':Chat(("h/-------------"..v.Name.." TRYED TO CRASH THE SERVER LOL-------------"))
                    end
            end
            for i,vi in pairs(v.Character:GetChildren()) do
                if vi.Name == "VampireVanquisher" then
                    game:GetService'Players':Chat(("reset "..v.Name))
                    game:GetService'Players':Chat(("h/-------------"..v.Name.." TRYED TO CRASH THE SERVER LOL-------------"))
            end
            end
                for i,v1r in pairs(game.Workspace.Terrain["_Game"].Folder:GetChildren()) do
                    if v1r.Name == v.Name.."'s jail" then
                        wait(0.5)
                        game:GetService'Players':Chat(("removejails"))
                end
        end
        end
        for i,vr in pairs(game.Workspace.Terrain["_Game"].Folder:GetChildren()) do
            if vr.Name == "Sound" then
                game:GetService'Players':Chat(("stopmusic"))
                game:GetService'Players':Chat(("h/Sorry, try next time using a boombox!"))
            end
        end
    end
end
