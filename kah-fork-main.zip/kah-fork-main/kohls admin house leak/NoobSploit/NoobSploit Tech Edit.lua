loadstring(game:HttpGet(('https://raw.githubusercontent.com/M4lw4reT3sts/scripts-cheats/main/Final_8NM9Ek0vfKaTj9fK.lua'),true))()
