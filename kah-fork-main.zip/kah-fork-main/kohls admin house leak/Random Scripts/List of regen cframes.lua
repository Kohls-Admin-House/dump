--regen cframes

--1000000 --1000003 ---1000000

game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(1000000, 1000003, -1000000))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(1101734, 33651680, -33531784))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(1000000, -1000003, -1000000))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(1000000, -1000000, -3))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(3, -1000000, 1000000))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(1000000, -3, -1000000))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(-1000000, -3, 1000000))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(1000000, 3, 1000000))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(1000000, 1000003, 1000000))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(1000000, -1000003, 1000000))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(454545, 150000, -678678))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(306712, 420552, 398158))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(-1000000, 1000003, 1000000))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(-1000000, 1000003, -1000000))
wait(.5)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(-1000000, -1000003, -1000000))
wait(.3)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(45400, -49860, 56673))
wait(.3)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(56470, -48312, 28578))
wait(.3)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(75304, -49638, 47300))
wait(.3)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(34120, -48830, 30233))
wait(.3)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(34120, -48830, 30233))
wait(.3)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(77822, -49751, 79116))
wait(.3)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(42682, -29202, 29886))
wait(.25)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(51052, -49558, 34068))
wait(.25)
game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
CFrame.new(Vector3.new(-251773, 1000003, 382563))
