```i checked out shortcut v2 via some youtube video, this might be that one admin script I was checking out a year or two ago
i dont really know how up to date it was and buttons didnt really explain too in depth so cant compare too well


anyway
i made this script a while ago havent updated because i either wanna rewrite it entirely or not update it, been procrastinating updating for a long time, open source, some parts are stolen, unoptimized and i have gotten warned for using it

i think this script is better from what i saw in the video, maybe their shutdown is better though, i used this with perm admin a very long time ago
commands are printed in console (shift+f9), theres a lot of commands so if you want a preview just look at the first few lines of the source code
Code:
loadstring(game:HttpGet("https://raw.githubusercontent.com/exceptional0/kohlsantikill/master/0000000kohlstrueantikill.txt",true))()

I'd like feedback on script
[-]unimportant comparison from what i saw
https://www.youtube.com/watch?v=XGCdOTIcFJE
their gui script (the enemy, rawr):
-they have a gui
-they have click to murder stuff
-"antiabuse" etc, buttons are undetailed
-not many commands from what i saw

my script:
-~50-100 commands, don't care enough to count again
-commands are somewhat detailed, however you have to open roblox's shitty console to see them

-very user friendly and gives user much control in my experience, don't care enough to cough up a bullshit explanation, theres also a gearpack command allowing you to create your own packs and not rely on premade ones.

-towered over and dominated other exploiters back when i used it a year or two ago
HOWEVER, some "new" crash method cannot be prevented by this script, don't have the method so cannot patch if its even patchable
-personal preference, but some protection commands are enabled by default, since I always use them anyway when using the script
-entirely free and open source, don't think there are any connections other than to github if i remember correctly

cons:
-no gui
-heard it was not compatible with some freesploits
-no click to murder stuff
-gotta open shitty roblox console to see commands
-not updated much
-unoptimized x2
-I'm not very contactable or that caring about this script, feel free to pm me or somehow find out my discord if you really want help or something```
