					elseif string.sub(command, 1, 9) == ":zawarudo" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 6) == ":purge" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ".perm" then
						game.Players:Chat(".sm Lol no joke but "..plr.Name.." uses the best script")
					elseif string.sub(command, 1, 8) == ":allpads" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ":rege" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 2) == ">t" then
						game.Players:Chat(",msg "..plr.Name..": I use kohls n00b")
						game.Players:Chat(".annoy "..plr.Name.."")
					elseif string.sub(command, 1, 2) == ">s" then
						game.Players:Chat(",msg "..plr.Name..": I use kohls n00b")
						game.Players:Chat(".annoy "..plr.Name.."")
					elseif string.sub(command, 1, 4) == ":kit" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ":pads" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ":bloc" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ":uhou" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ":spaw" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 3) == ":Go" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ":Stop" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ":remo" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 4) == ":skh" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ":inve" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(",msg l "..plr.Name.." l Has chosen the easy way out")
					elseif string.sub(command, 1, 4) == ":hmm" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 4) == ":dab" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ":admi" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
					elseif string.sub(command, 1, 5) == ":erro" then
						game.Players:Chat(",msg "..plr.Name..": I use Admin joy trash")
						game.Players:Chat("punish "..plr.Name.."")
						game.Players:Chat(".unadmin "..plr.Name.."")
