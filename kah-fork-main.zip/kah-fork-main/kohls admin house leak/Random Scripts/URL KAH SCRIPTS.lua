https://sites.google.com/view/kohlsploitezlmfao/home
Made by ComicallyLogical#3356 (that script is rlly good and please dont bully creator)

loadstring(game:HttpGet(('https://pastebin.com/raw/0m8dsrDH'),true))()
Script Made By @Jotunn#7339

loadstring(game:HttpGet('https://gist.githubusercontent.com/ScaleneSoap9803/3828d1ec1bec480b60f41b29e346bb93/raw/6614198753a67ab35d7970b6a8acb6ea9d30ce34/Night%2520Kohls%2520Beta'))()
Night Kohls Beta Made By @ScaleneSoap9803

a script @ScaleneSoap9803#0927 made ages ago with most of the things not working but still decent
loadstring(game:HttpGet('https://gist.githubusercontent.com/ScaleneSoap9803/58f36df9ccc980051f0062c1d4f2492b/raw/a701e4fa8598f9b41e3a9619d816d01b42d71498/Cool%2520Script%2520ig'))()

KohlsCool (invite: https://discord.gg/NjVdgxNjG4)
loadstring(game:HttpGet("https://krypton.sergioesquina.repl.co/roblox/exploit/script/KohlsCool/preview", true))
