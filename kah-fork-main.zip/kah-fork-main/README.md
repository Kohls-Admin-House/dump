fork of damix's repo
i reorganised some stuff

cool, this is now a backup :D
